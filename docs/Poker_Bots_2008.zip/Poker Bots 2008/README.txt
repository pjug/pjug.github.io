1:19 PM 9/1/2008

This is the Poker Bots 2008 presentation
from the Portland Java User's Group meeting
held August 19 2008.

The PPT file is an Office 97 - 2003 version
of the PPTX (Office 2007) file.

The slides are all saved as separate .PNG files too.
