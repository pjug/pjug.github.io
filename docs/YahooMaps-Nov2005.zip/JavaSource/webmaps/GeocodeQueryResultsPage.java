package webmaps;

import wicket.markup.html.WebPage;
import wicket.markup.html.basic.Label;
import java.math.*;

public class GeocodeQueryResultsPage extends WebPage {
	
	  public GeocodeQueryResultsPage(String location, BigDecimal lat, BigDecimal longitude)
	  {
	        add(new Label("location", location));
	        add(new Label("latitude", String.valueOf(lat)));
	        add(new Label("longitude", String.valueOf(longitude)));
	  }
	  
}
