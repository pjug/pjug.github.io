package webmaps;

import wicket.AttributeModifier;
import wicket.markup.html.form.Form;
import wicket.markup.html.form.TextField;
import wicket.markup.html.form.RequiredTextField;
import wicket.model.Model;
import wicket.model.PropertyModel;
import ymaps.DAOFactory;
import ymaps.ImageParameters;
import ymaps.ImageType;
import ymaps.MapsDAO;

public class MapQueryForm extends Form {
		private MapQuery query = new MapQuery();
		
		public MapQueryForm(final String componentName)
		{
			super(componentName);
			
			TextField location = new RequiredTextField("location", new PropertyModel(query, "location"));
			location.setConvertEmptyInputStringToNull(true);
			location.add(new AttributeModifier("size", new Model("40")));
			add(location);
		}

		public final void onSubmit()
		{
			String location = query.getLocation();
			byte[] imgData = getImageBytes(location);
			setResponsePage(new DisplayMapPage(imgData, location));
		}
		
		  private byte[] getImageBytes(String location)
		  {
				MapsDAO dao = DAOFactory.createMapsDAO();
				
				// Coordinate coord = dao.geocode(location);
				
				ImageParameters imgParam = new ImageParameters();
				imgParam.setType(ImageType.PNG);
				imgParam.setZoomLevel(3);
				
				// byte[] pngData = dao.getMapImageBytes(coord, imgParam);
				
				byte[] pngData = dao.getMapImageBytes(location, imgParam);
				return pngData;
		  }
		
}
