package webmaps;

import wicket.markup.html.WebPage;
import wicket.markup.html.image.Image;
import wicket.markup.html.basic.Label;

public class DisplayMapPage extends WebPage {
	
	  public DisplayMapPage(byte[] imgData, String message)
	   {
	        add(new Label("message", message));
	        add(new Image("map_image", new MapImageResource(imgData)));
	   }
	  
}
