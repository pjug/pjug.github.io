package webmaps;

import wicket.ApplicationSettings;
import wicket.protocol.http.WebApplication;

public class MapsApplication extends WebApplication {
	public static final String MAP_IMAGE_TYPE = "PNG";
	public static final String MAP_MIME_TYPE = "image/png";
	
	static
	{
		initLogging();
	}
	
	private static void initLogging()
	{
		System.setProperty("org.apache.commons.logging.Log", "org.apache.commons.logging.impl.SimpleLog");
		System.setProperty("org.apache.commons.logging.simplelog.showdatetime", "true");
		System.setProperty("org.apache.commons.logging.simplelog.log.httpclient.wire.header", "debug");
		System.setProperty("org.apache.commons.logging.simplelog.log.org.apache.commons.httpclient", "debug");
	}
	
	public MapsApplication()
    {
        getPages().setHomePage(HomePage.class);
    }
	
	public ApplicationSettings createApplicationSettings() 
	{
		ApplicationSettings s = new ApplicationSettings(this);
        s.setDefaultMarkupEncoding("UTF-8");
        s.setResourcePollFrequency(wicket.util.time.Duration.ONE_SECOND);
        return s;
    }
}
