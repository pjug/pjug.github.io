package webmaps;

import wicket.markup.html.WebPage;
import wicket.markup.html.basic.Label;

public class HomePage extends WebPage {
	
	  public HomePage()
	   {
	        add(new Label("message", "Hello user!"));
	   }
}
