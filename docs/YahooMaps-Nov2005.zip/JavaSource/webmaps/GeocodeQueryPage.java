package webmaps;

import wicket.markup.html.WebPage;
import wicket.markup.html.basic.Label;

public class GeocodeQueryPage extends WebPage {
	
	  public GeocodeQueryPage()
	   {
	        add(new Label("message", "Geocoding"));
	        add(new GeocodeQueryForm("geocodeQueryForm"));
	   }
}
