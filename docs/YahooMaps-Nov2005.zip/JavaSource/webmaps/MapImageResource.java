package webmaps;

import wicket.resource.DynamicByteArrayResource;

public class MapImageResource extends DynamicByteArrayResource {

	private byte[] imgData;
	
	public MapImageResource(byte[] data)
	{
		this.imgData = data;
	}
	
	@Override
	public String getContentType() {
		return MapsApplication.MAP_MIME_TYPE;
	}

	@Override
	protected byte[] getData() {
		return imgData;
	}

}
