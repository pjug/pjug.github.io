package webmaps;

import java.io.Serializable;

public class MapQuery implements Serializable {
	private String location;

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}
}
