
package webmaps;

import wicket.AttributeModifier;
import wicket.markup.html.form.Form;
import wicket.markup.html.form.TextField;
import wicket.markup.html.form.RequiredTextField;
import wicket.model.Model;
import wicket.model.PropertyModel;
import ymaps.*;
import yahooMaps.*;

public class GeocodeQueryForm extends Form {
		private MapQuery query = new MapQuery();
		
		public GeocodeQueryForm(final String componentName)
		{
			super(componentName);
			
			TextField location = new RequiredTextField("location", new PropertyModel(query, "location"));
			location.setConvertEmptyInputStringToNull(true);
			location.add(new AttributeModifier("size", new Model("40")));
			add(location);
		}

		public final void onSubmit()
		{
			String location = query.getLocation();
			System.out.println(location);
			
			MapsDAO dao = DAOFactory.createMapsDAO();
			ResultType result = dao.geocode(location);
		
			setResponsePage(new GeocodeQueryResultsPage(location, result.getLatitude(), result.getLongitude()));
		}
		
}
