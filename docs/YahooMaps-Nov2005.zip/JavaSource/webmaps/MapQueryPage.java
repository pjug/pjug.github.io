package webmaps;

import wicket.markup.html.WebPage;
import wicket.markup.html.basic.Label;

public class MapQueryPage extends WebPage {
	
	  public MapQueryPage()
	   {
	        add(new Label("message", "Need a map?"));
	        add(new MapQueryForm("mapForm"));
	   }
}
