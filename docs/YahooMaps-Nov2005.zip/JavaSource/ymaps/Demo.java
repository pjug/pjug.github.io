package ymaps;

import java.io.*;

public class Demo {
	
	
	public static void main(String[] args) throws Exception
	{
		
		String appId = "put-your-application-id-here";
		
		MapsDAO dao = DAOFactory.createMapsDAO(appId);
		
		String location = "2055 NW Savier St Portland Oregon 97210";
		
		// Coordinate coord = dao.geocode(location);
		
		ImageParameters imgParam = new ImageParameters();
		imgParam.setType(ImageType.PNG);
		imgParam.setZoomLevel(3);
		
		// byte[] pngData = dao.getMapImageBytes(coord, imgParam);
		
		byte[] pngData = dao.getMapImageBytes(location, imgParam);
		
		FileOutputStream fos = new FileOutputStream("foo.png");
		fos.write(pngData);
		fos.flush();
		fos.close();
		
	}
}
