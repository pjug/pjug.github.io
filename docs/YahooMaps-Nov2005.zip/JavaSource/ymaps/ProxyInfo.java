package ymaps;

public class ProxyInfo {
	static public String getHostname()
	{
		return "your-proxy-hostname";
	}
	
	static public int getPort()
	{
		return 8080;
	}
	
	static public String getUser()
	{
		return "user1";
	}
	
	static public String getPassword()
	{
		return "password1";
	}
}
