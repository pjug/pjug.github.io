
package ymaps;

import java.net.InetAddress;
import java.net.URLEncoder;

import org.apache.commons.httpclient.*;
import org.apache.commons.httpclient.auth.*;
import org.apache.commons.httpclient.params.*;
import org.apache.commons.httpclient.methods.*;
import org.jdom.*;
import org.jdom.input.*;
import org.jdom.xpath.*;
import com.opensymphony.oscache.base.*;
import com.opensymphony.oscache.general.*;
import yahooMaps.*;
import java.util.*;
import java.io.*;

public class YahooMapsDAO implements MapsDAO {
	private static final String GEOCODE_URL = "http://api.local.yahoo.com/MapsService/V1/geocode";
	private static final String MAP_IMAGE_URL = "http://api.local.yahoo.com/MapsService/V1/mapImage";
	private static final int CACHE_REFRESH_PERIOD = 60 * 1000; // MILLISECONDS
	private String appId;
	
	private HttpClient httpClient;
	
	private static GeneralCacheAdministrator cache;
	
	static
	{
		Properties cacheProps = new Properties();
		cacheProps.put(AbstractCacheAdministrator.CACHE_MEMORY_KEY, "true");
		cacheProps.put(AbstractCacheAdministrator.CACHE_CAPACITY_KEY, "5000");
		cache = new GeneralCacheAdministrator(cacheProps);
	}
	
	public YahooMapsDAO(String applicationId)
	{
		this.appId = applicationId;
	}


	public ResultType geocode(String location) {
		HttpClient client = getHttpClient();

		String urlParams = "?appid="
						+ encode(appId)
						+ "&location="
						+ encode(location);
 
		String url = GEOCODE_URL + urlParams;
		
		GetMethod get = createGetMethod(url);
		
		
		try
		{
			int httpResponseCode = client.executeMethod(get);
			
			checkResponseCode(httpResponseCode, get);
			
			ResultSetDocument doc = ResultSetDocument.Factory.parse(get.getResponseBodyAsStream());
			ResultType[] results = doc.getResultSet().getResultArray();
			
			return results[0];
		}
		catch (Exception ex)
		{
			throw new RuntimeException(ex);
		}
	}

	protected String encode(String url)
	{
		try
		{
			return URLEncoder.encode(url, "UTF-8");
		}
		catch (UnsupportedEncodingException ex)
		{
			throw new RuntimeException(ex);
		}
	}
	protected void checkResponseCode(int code, HttpMethodBase method)
	{
		if (code != 200)
		{
			String response = null;
			try
			{
				response = method.getResponseBodyAsString();
				System.err.println(response);
			}
			catch (java.io.IOException ex)
			{
				response = "";
			}
			throw new RuntimeException("HTTP response code = " + code + " " + response);
		}
		
	}
	
	public Coordinate geocode(Location loc) {
		// TODO Auto-generated method stub
		return null;
	}

	public byte[] getMapImageBytes(String location, ImageParameters param) {
		
		HttpClient client = getHttpClient();
		PostMethod post = createPostMethod(MAP_IMAGE_URL);
		
		post.addParameter("appid", this.appId);
		post.addParameter("location", location);
		post.addParameter("image_type", param.getType().getType());
		post.addParameter("image_height", "" + param.getImageHeight());
		post.addParameter("image_width", "" + param.getImageWidth());
		post.addParameter("zoom", "" + param.getZoomLevel());
		
		try
		{
			int httpResponseCode = client.executeMethod(post);
			
			checkResponseCode(httpResponseCode, post);
			
			Document doc = new SAXBuilder(false).build(post.getResponseBodyAsStream());
			
			Element resultElement = (Element) XPath.newInstance("/Result").selectSingleNode(doc);
			
			String imageUrl = resultElement.getText();

			return getImageBytesFromUrl(imageUrl);
		}
		catch (Exception ex)
		{
			throw new RuntimeException(ex);
		}
	}

	protected byte[] getImageBytesFromUrl(String url) throws HttpException, java.io.IOException
	{
		
		String cacheKey = url;
		byte[] imageBytes = null;
		
		try 
		{
		     imageBytes = (byte[]) cache.getFromCache(cacheKey, CACHE_REFRESH_PERIOD);
		} 
		catch (NeedsRefreshException nre) 
		{
		     try 
		     {
		 		GetMethod get = createGetMethod(url);
				int httpResponseCode = getHttpClient().executeMethod(get);
				checkResponseCode(httpResponseCode, get);
				imageBytes = get.getResponseBody();
		        // Store in the cache
		        cache.putInCache(cacheKey, imageBytes);
		     } 
		     catch (Exception ex) 
		     {
		         // We have the current content if we want fail-over.
		         imageBytes = (byte[]) nre.getCacheContent();
		         // It is essential that cancelUpdate is called if the
		         // cached content is not rebuilt
		         cache.cancelUpdate(cacheKey);
		     }
		 }		
		return imageBytes;
	}
	
	protected GetMethod createGetMethod(String url)
	{
		GetMethod get = new GetMethod(url);
		return get;
	}
	
	protected PostMethod createPostMethod(String url)
	{
		PostMethod post = new PostMethod(url);
		return post;
	}
	
	public byte[] getMapImageBytes(Coordinate coord, ImageParameters param) {
		// TODO Auto-generated method stub
		return null;
	}

	public byte[] getMapImageBytes(Location loc, ImageParameters param) {
		// TODO Auto-generated method stub
		return null;
	}

	protected HttpClient getHttpClient()
	{
		if (httpClient == null)
		{
			HttpClientParams params = new HttpClientParams();
			params.setConnectionManagerTimeout(10000); // milliseconds
			httpClient = new HttpClient(params);
			httpClient.getHostConfiguration().setProxy(ProxyInfo.getHostname(), ProxyInfo.getPort());
			HttpState state = httpClient.getState();
			
			try
			{
				Credentials cred = new NTCredentials(
											ProxyInfo.getUser(), 
											ProxyInfo.getPassword(),
											InetAddress.getLocalHost().getHostName(),
											"CFI");
				state.setProxyCredentials(AuthScope.ANY, cred);
			}
			catch (Exception ex)
			{
				throw new RuntimeException(ex);
			}
		}
		return httpClient;
	}
}
