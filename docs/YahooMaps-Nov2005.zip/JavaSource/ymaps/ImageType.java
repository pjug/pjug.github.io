package ymaps;

public enum ImageType {
	PNG  ( "png" ),
	GIF ( "gif" );
	
	private String type;
	
	ImageType(String type)
	{
		this.type = type;
	}
	
	public String getType()
	{
		return type;
	}
	
}

