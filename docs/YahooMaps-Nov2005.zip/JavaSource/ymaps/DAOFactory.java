package ymaps;

public class DAOFactory 
{
	private DAOFactory()
	{
		// private
	}
	
	static public MapsDAO createMapsDAO(String appId)
	{
		return new YahooMapsDAO(appId);
	}
	
	static public MapsDAO createMapsDAO()
	{
		return new YahooMapsDAO("your-application-id");
	}
	
}
