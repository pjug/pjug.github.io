package ymaps;

import yahooMaps.ResultType;

public interface MapsDAO {
	public ResultType geocode(String location);
	public byte[] getMapImageBytes(String location, ImageParameters param);
	public byte[] getMapImageBytes(Coordinate coord, ImageParameters param);
	public byte[] getMapImageBytes(Location loc, ImageParameters param);
}
