package ymaps;

import java.math.*;

public class ImageParameters {
	private int imageHeight = 500;
	private int imageWidth = 500;
	private ImageType type = ImageType.PNG;
	private int zoomLevel = 6;
	private BigDecimal radius;
	
	public int getImageHeight() {
		return imageHeight;
	}
	public void setImageHeight(int height) {
		this.imageHeight = height;
	}
	public int getImageWidth() {
		return imageWidth;
	}
	public void setImageWidth(int width) {
		this.imageWidth = imageWidth;
	}
	public BigDecimal getRadius() {
		return radius;
	}
	public void setRadius(BigDecimal r) {
		this.radius = r;
	}
	public ImageType getType() {
		return type;
	}
	public void setType(ImageType type) {
		this.type = type;
	}
	public int getZoomLevel() {
		return zoomLevel;
	}
	public void setZoomLevel(int zoomLevel) {
		this.zoomLevel = zoomLevel;
	}
}
