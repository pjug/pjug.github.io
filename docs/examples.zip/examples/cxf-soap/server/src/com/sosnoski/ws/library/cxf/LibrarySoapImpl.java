/**
 * Licensed to the Apache Software Foundation (ASF) under one or more contributor license agreements. See the NOTICE
 * file distributed with this work for additional information regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

package com.sosnoski.ws.library.cxf;

import java.util.List;

/**
 * Implementation class for book server access as web service.
 */
@javax.jws.WebService(endpointInterface="com.sosnoski.ws.library.cxf.Library",
    portName="library", targetNamespace="http://ws.sosnoski.com/library/wsdl",
    serviceName="Library")
public class LibrarySoapImpl implements Library
{
    public void addBook(String type, String isbn, List<String> author, String title) {
        BookInformation book = new BookInformation();
        book.getAuthor().addAll(author);
        book.setIsbn(isbn);
        book.setTitle(title);
        book.setType(type);
        BookServer.addBook(book);
    }

    public BookInformation getBook(String isbn) {
        return BookServer.getBook(isbn);
    }

    public List<BookInformation> getBooksByType(String type) {
        return BookServer.getBooksByType(type);
    }

    public List<TypeInformation> getTypes() {
        return BookServer.getTypes();
    }

    public void addType(String name, String description) {
        TypeInformation type = new TypeInformation();
        type.setName(name);
        type.setValue(description);
        BookServer.addType(type);
    }

    public List<BookInformation> getAllBooks() {
        return BookServer.getBooks();
    }

    public void deleteBook(String isbn) {
        BookServer.deleteBook(isbn);
    }
}