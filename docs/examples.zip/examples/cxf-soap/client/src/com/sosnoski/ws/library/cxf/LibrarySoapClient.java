/**
 * Licensed to the Apache Software Foundation (ASF) under one or more contributor license agreements. See the NOTICE
 * file distributed with this work for additional information regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

package com.sosnoski.ws.library.cxf;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;
import javax.xml.ws.Service;
import javax.xml.ws.soap.SOAPBinding;

/**
 * Web service client for book server. This runs through a test of the service
 * methods, first retrieving a book, then adding a book, and finally retrieving
 * all books of a particular type.
 */
public class LibrarySoapClient
{
    public static void main(String[] args) throws Exception {
        
        // check for required command line parameters
        if (args.length < 3) {
            System.out.println("Usage:\n  java com.sosnoski.ws.library.cxf.soap.LibrarySoapClient host port path");
            System.exit(1);
        }
        
        // create the client stub
        Library_Service service = new Library_Service();
        Library stub = service.getLibrary();
        
        // set the actual endpoint address
        String target = "http://" + args[0] + ":" + args[1] + args[2];
        System.out.println("Connecting to " + target);
        BindingProvider provider = (BindingProvider)stub;
        provider.getRequestContext().put(BindingProvider.ENDPOINT_ADDRESS_PROPERTY, target);
        
        // list all the books in the library
        List<BookInformation> books = stub.getAllBooks();
        System.out.println("Retrieved " + books.size() + " books in library:");
        for (int i = 0; i < books.size(); i++) {
            System.out.println(" '" + books.get(i).getTitle() + '\'');
        }
        
        // retrieve a single book directly
        String isbn = "0061020052";
        BookInformation book = stub.getBook(isbn);
        System.out.println("Retrieved '" + book.getTitle() + '\'');
        
        // retrieve the list of types defined
        List<TypeInformation> types = stub.getTypes();
        System.out.println("Retrieved " + types.size() + " types:");
        for (TypeInformation type : types) {
            System.out.println(" '" + type.getName() + "' with " + type.getCount() + " books");
        }
        
        // add a new book
        String title = "The Dragon Never Sleeps";
        isbn = "0445203498";
        stub.addBook("scifi", isbn, Collections.singletonList("Cook, Glen"), title);
        System.out.println("Added '" + title + '\'');
        
        // get all books of a type
        books = stub.getBooksByType("scifi");
        System.out.println("Retrieved " + books.size() + " books of type 'scifi':");
        for (Iterator<BookInformation> iter = books.iterator(); iter.hasNext();) {
            System.out.println(" '" + iter.next().getTitle() + '\'');
        }
        
        // delete the book added earlier
        stub.deleteBook(isbn);
        System.out.println("Deleted added book");
        
        // add a new type
        stub.addType("mind", "The mind and brain");
        
        // add a new book of that type
        title = "The Undiscovered Self";
        isbn = "0451217322";
        book = new BookInformation();
        book.setType("mind");
        book.setIsbn(isbn);
        book.getAuthor().add("Jung, Carl G.");
        book.setTitle(title);
        stub.addBook("mind", isbn, Collections.singletonList("Jung, Carl G."), title);
        System.out.println("Added '" + title + '\'');
        
        // get all books of new type
        books = stub.getBooksByType("mind");
        System.out.println("Retrieved " + books.size() + " books of type 'mind':");
        for (Iterator<BookInformation> iter = books.iterator(); iter.hasNext();) {
            System.out.println(" '" + iter.next().getTitle() + '\'');
        }
    }
}