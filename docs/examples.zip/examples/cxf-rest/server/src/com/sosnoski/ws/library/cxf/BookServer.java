/**
 * Licensed to the Apache Software Foundation (ASF) under one or more contributor license agreements. See the NOTICE
 * file distributed with this work for additional information regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

package com.sosnoski.ws.library.cxf;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Book server class. This creates an initial library of books when the class is loaded, then supports method calls to
 * access the library information (including adding new books). All access uses static methods so that changes to the
 * library will always be visible to later operations.
 */
public class BookServer
{
    private static final Map<String,TypeInformation> m_typeMap;
    private static final Map<String,BookInformation> m_bookMap;
    static {
        m_typeMap = new HashMap<String,TypeInformation>();
        internalAdd(newType("java", "About Java"));
        internalAdd(newType("scifi", "Science fiction"));
        internalAdd(newType("xml", "About XML"));
        m_bookMap = new HashMap<String,BookInformation>();
        internalAdd(newBook("java", "0136597238", "Thinking in Java",
            new String[] { "Eckel, Bruce" }));
        internalAdd(newBook("xml", "0130655678", "Definitive XML Schema",
            new String[] { "Walmsley, Priscilla" }));
        internalAdd(newBook("scifi", "0061020052", "Infinity Beach",
            new String[] { "McDevitt, Jack" }));
        internalAdd(newBook("scifi", "0812514092", "Aristoi",
            new String[] { "Williams, Walter Jon" }));
        internalAdd(newBook("java", "0201633612", "Design Patterns",
            new String[] { "Gamma, Erich", "Helm, Richard", "Johnson, Ralph",
                "Vlissides, John"}));
        internalAdd(newBook("scifi", "0345253884", "Roadmarks",
            new String[] { "Zelazny, Roger" }));
        internalAdd(newBook("xml", "0596002521", "XML Schema",
            new String[] { "van der Vlist, Eric" }));
        internalAdd(newBook("java", "0079132480",
            "Inside the Java Virtual Machine",
            new String[] { "Venners, Bill" }));
    }
    
    private static TypeInformation newType(String name, String desc) {
        TypeInformation type = new TypeInformation();
        type.setName(name);
        type.setValue(desc);
        return type;
    }
    
    private static BookInformation newBook(String type, String isbn,
        String title, String[] authors) {
        BookInformation book = new BookInformation();
        book.setType(type);
        book.setIsbn(isbn);
        book.setTitle(title);
        for (int i = 0; i < authors.length; i++) {
            book.getAuthor().add(authors[i]);
        }
        return book;
    }
    
    private static boolean internalAdd(TypeInformation type) {
        if (m_typeMap.containsKey(type.getName())) {
            return false;
        } else {
            m_typeMap.put(type.getName(), type);
            return true;
        }
    }

    private static boolean internalDelete(String isbn) {
        BookInformation book = m_bookMap.remove(isbn);
        if (book == null) {
            return false;
        } else {
            TypeInformation type = m_typeMap.get(book.getType());
            type.setCount(type.getCount()-1);
            return true;
        }
    }

    private static boolean internalAdd(BookInformation book) {
        if (m_bookMap.containsKey(book.getIsbn())) {
            return false;
        } else {
            TypeInformation type = m_typeMap.get(book.getType());
            if (type == null) {
                throw new IllegalArgumentException("Type " + book.getType() + " not defined");
            } else {
                type.setCount(type.getCount()+1);
                m_bookMap.put(book.getIsbn(), book);
                return true;
            }
        }
    }
    
    public static synchronized BookInformation getBook(String isbn) {
        return (BookInformation)m_bookMap.get(isbn);
    }
    
    public static synchronized List<BookInformation> getBooksByType(String type) {
        List<BookInformation> matches = new ArrayList<BookInformation>();
        for (BookInformation book : m_bookMap.values()) {
            if (type.equals(book.getType())) {
                matches.add(book);
            }
        }
        return matches;
    }
    
    public static List<BookInformation> getBooks() {
        return new ArrayList<BookInformation>(m_bookMap.values());
    }
    
    public static List<TypeInformation> getTypes() {
        return new ArrayList<TypeInformation>(m_typeMap.values());
    }
    
    public static synchronized boolean addBook(BookInformation book) {
        return internalAdd(book);
    }
    
    public static synchronized boolean deleteBook(String isbn) {
        return internalDelete(isbn);
    }
    
    public static synchronized boolean addType(TypeInformation type) {
        return internalAdd(type);
    }
    
    public static synchronized boolean deleteType(String tname) {
        TypeInformation type = m_typeMap.get(tname);
        if (type == null) {
            return false;
        } else {
            for (BookInformation book : m_bookMap.values()) {
                if (type.equals(book.getType())) {
                    internalDelete(book.getIsbn());
                }
            }
            m_typeMap.remove(tname);
            return true;
        }
    }
}