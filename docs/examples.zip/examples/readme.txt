To build and run the examples you'll need to edit the build.properties to set
the path to your CXF installation. The build files are set up for CXF 2.4.1, but
should be compatible with later releases in the 2.4.x series. For releases 2.5.x
and later you'll probably need to edit the names of the CXF jar files included
in the war files.

You may also need to change the host-name and host-port parameters in the
build.properties file.

Once you've edited the build.properties you can build either example by typing
"ant" at a console in the example directory. If you're running Tomcat and have
configured the tomcat/tomcat user with manager permissions, and have copied the
Tomcat catalina-ant.jar to your Ant installation's lib directory, you can use
"ant deploy" to deploy the service war to Tomcat (and "ant undeploy" to remove
a deployed service).

Once you've deployed the war to your app server you can type "ant run" to run
the client code.
