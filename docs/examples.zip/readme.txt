To build and run the examples you'll need to edit the build.properties to set
the path to your CXF installation. The build files are set up for CXF 2.4.2, but
should be compatible with later releases in the 2.4.x series. For releases 2.5.x
and later you'll probably need to edit the names of the CXF jar files included
in the war files.

You may also need to change the host-name and host-port parameters in the
build.properties file.

Once you've edited the build.properties you can build either example by typing
"ant" at a console in the example directory. If you're running Tomcat and have
configured the tomcat/tomcat user with manager permissions, and have copied the
Tomcat catalina-ant.jar to your Ant installation's lib directory, you can use
"ant deploy" to deploy the service war to Tomcat ("ant undeploy" to remove a
deployed service, and "ant redeploy" to redeploy a deployed service).

Once you've deployed the war to your app server you can type "ant run" to run
the client code.

You can also work with the examples in Eclipse. First set up a User Library
(Window/Preferences menu, Java/Build Path/User Libraries selection, "New..."
button) named CXF, and add all the jar files from your CXF installation's lib
directory. Then import the projects (File/Import menu, General/Existing Projects
into Workspace) from the "examples" directory into your workspace. Note that you
need to build the projects with Ant first, in order to create the "gen"
directory containing the common generated code - otherwise you'll get build path
problems.

Here's the list of examples:

rest1: Demonstration of REST with JAX-RS service deployed via war file, generic
  WebClient client interface, data model generated from schema
rest2: REST with JAX-RS service run in-process, client proxy generated from
  service interface, client logging through direct interceptor configuration and
  through feature
soap1: Demonstration of SOAP with JAX-WS service deployed via war file, data
  model and service interface generated from WSDL
soap2: SOAP with WS-Security used to sign all messages bodies.

Note that although the same basic build structure is used in each case the
specific CXF jars that need to be included in the war are different depending on
the features being used. See the WHICH_JARS file contained in the CXF
distribution /lib directory for details. One of the main benefits of using Maven
for CXF project builds is that it simplifies the details of feature dependency
management, and generally my actual training classes use Maven rather than Ant.
