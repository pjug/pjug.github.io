/**
 * Licensed to the Apache Software Foundation (ASF) under one or more contributor license agreements. See the NOTICE
 * file distributed with this work for additional information regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

package com.sosnoski.ws.library.cxf;

import javax.xml.bind.JAXBElement;

import org.apache.cxf.endpoint.Server;
import org.apache.cxf.jaxrs.JAXRSBindingFactory;
import org.apache.cxf.jaxrs.JAXRSServerFactoryBean;
import org.apache.cxf.transport.http_jetty.JettyHTTPServerEngine;
import org.apache.cxf.transport.http_jetty.JettyHTTPServerEngineFactory;

/**
 * Implementation class for book server access as web service.
 */
public class LibraryRestImpl implements LibraryRestInterface
{
    private final ObjectFactory m_factory;
    
    public LibraryRestImpl() {
        m_factory = new ObjectFactory();
    }
    
    public BookList getAllBooks() {
        BookList list = new BookList();
        list.getBook().addAll(BookServer.getBooks());
        return list;
    }

    public JAXBElement<BookInformation> getBook(String isbn) {
        return m_factory.createBook(BookServer.getBook(isbn));
    }
    
    public void addBook(JAXBElement<BookInformation> book) {
        BookServer.addBook(book.getValue());
    }
    
    public void deleteBook(String isbn) {
        BookServer.deleteBook(isbn);
    }
    
    public TypeList getTypes() {
        TypeList list = new TypeList();
        list.getType().addAll(BookServer.getTypes());
        return list;
    }

    public BookList getBooksByType(String type) {
        BookList list = new BookList();
        list.getBook().addAll(BookServer.getBooksByType(type));
        return list;
    }
    
    public void addType(JAXBElement<TypeInformation> type) {
        BookServer.addType(type.getValue());
    }
    
    public static void main(String[] args) throws Exception {
        JettyHTTPServerEngine engine = new JettyHTTPServerEngineFactory().createJettyHTTPServerEngine(8081, "http");
        JAXRSServerFactoryBean sf = new JAXRSServerFactoryBean();
    	sf.setServiceClass(LibraryRestImpl.class);
    	sf.setBindingId(JAXRSBindingFactory.JAXRS_BINDING_ID);
    	sf.setAddress("http://localhost:8081/cxf-library-rest");
    	Server server = sf.create();
    	synchronized (LibraryRestImpl.class) {
    		try {
				LibraryRestImpl.class.wait(60000);
			} catch (InterruptedException e) {
				// ignore
			}
    	}
    	server.stop();
    	server.destroy();
    	engine.shutdown();
    }
}