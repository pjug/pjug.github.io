/**
 * Licensed to the Apache Software Foundation (ASF) under one or more contributor license agreements. See the NOTICE
 * file distributed with this work for additional information regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

package com.sosnoski.ws.library.cxf;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.xml.bind.JAXBElement;

/**
 * Implementation class for book server access as web service.
 */
@Path("")
@Produces("application/xml")
public class LibraryRestImpl
{
    private final ObjectFactory m_factory;
    
    public LibraryRestImpl() {
        m_factory = new ObjectFactory();
    }
    
    @GET @Path("books") @Produces({"application/xml", "application/json"})
    public BookList getAllBooks() {
        BookList list = new BookList();
        list.getBook().addAll(BookServer.getBooks());
        return list;
    }
    
    @GET @Path("booksjson")
    @Produces("application/json")
    public BookList getAllBooksJson() {
        BookList list = new BookList();
        list.getBook().addAll(BookServer.getBooks());
        return list;
    }

    @GET @Path("books/{isbn}")
    public JAXBElement<BookInformation> getBook(@PathParam("isbn") String isbn) {
        return m_factory.createBook(BookServer.getBook(isbn));
    }
    
    @PUT @Path("books")
    public void addBook(BookInformation book) {
        BookServer.addBook(book);
    }
    
    @DELETE @Path("books/{isbn}")
    public void deleteBook(@PathParam("isbn") String isbn) {
        BookServer.deleteBook(isbn);
    }
    
    @GET @Path("types")
    public TypeList getTypes() {
        TypeList list = new TypeList();
        list.getType().addAll(BookServer.getTypes());
        return list;
    }

    @GET @Path("types/{type}")
    public BookList getBooksByType(@PathParam("type") String type) {
        BookList list = new BookList();
        list.getBook().addAll(BookServer.getBooksByType(type));
        return list;
    }
    
    @PUT @Path("types")
    public void addType(TypeInformation type) {
        BookServer.addType(type);
    }
}