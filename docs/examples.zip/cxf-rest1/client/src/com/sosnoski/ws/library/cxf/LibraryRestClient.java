/**
 * Licensed to the Apache Software Foundation (ASF) under one or more contributor license agreements. See the NOTICE
 * file distributed with this work for additional information regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */

package com.sosnoski.ws.library.cxf;

import java.util.Iterator;

import org.apache.cxf.jaxrs.client.WebClient;

/**
 * Web service client for book server. This runs through a test of the service methods, first retrieving a book, then
 * adding a book, and finally retrieving all books of a particular type.
 */
public class LibraryRestClient
{
    public static void main(String[] args) throws Exception {
        
        // check for required command line parameters
        if (args.length < 3) {
            System.out.println("Usage:\n  java com.sosnoski.ws.library.cxf.rest.LibraryRestClient host port path");
            System.exit(1);
        }
        
        // build HTTP client for actual endpoint address
        String target = "http://" + args[0] + ":" + args[1] + args[2];
        System.out.println("Connecting to " + target);
        WebClient client = WebClient.create(target);
        
        // retrieve a single book directly
        String isbn = "0061020052";
        BookInformation book = client.reset().path("books/" + isbn).accept("application/xml").get(BookInformation.class);
        System.out.println("Retrieved '" + book.getTitle() + '\'');
        
        // list all the books in the library
        BookList books = client.reset().path("books").accept("application/xml").get(BookList.class);
        System.out.println("Retrieved " + books.getBook().size() + " books in library:");
        for (Iterator<BookInformation> iter = books.getBook().iterator(); iter.hasNext();) {
            System.out.println(" '" + iter.next().getTitle() + '\'');
        }
        
        // retrieve the list of types defined
        TypeList types = client.reset().path("types").accept("application/xml").get(TypeList.class);
        System.out.println("Retrieved " + types.getType().size() + " types:");
        for (TypeInformation type : types.getType()) {
            System.out.println(" '" + type.getName() + "' with " + type.getCount() + " books");
        }
        
        // add a new book
        String title = "The Dragon Never Sleeps";
        String addisbn = "0445203498";
        book = new BookInformation();
        book.setType("scifi");
        book.setIsbn(addisbn);
        book.getAuthor().add("Cook, Glen");
        book.setTitle(title);
        ObjectFactory factory = new ObjectFactory();
        client.reset().path("books").put(factory.createBook(book));
        System.out.println("Added '" + title + '\'');
        
        // get all books of a type
        books = client.reset().path("types/scifi").accept("application/xml").get(BookList.class);
        System.out.println("Retrieved " + books.getBook().size() + " books of type 'scifi':");
        for (Iterator<BookInformation> iter = books.getBook().iterator(); iter.hasNext();) {
            System.out.println(" '" + iter.next().getTitle() + '\'');
        }
        
        // add a new type 'mind'
        // ...
        
        // add a new book of that type
        title = "The Undiscovered Self";
        addisbn = "0451217322";
        // ...
        
        // get all books of new type
        books = client.reset().path("types/mind").accept("application/xml").get(BookList.class);
        System.out.println("Retrieved " + books.getBook().size() + " books of type 'mind':");
        for (Iterator<BookInformation> iter = books.getBook().iterator(); iter.hasNext();) {
            System.out.println(" '" + iter.next().getTitle() + '\'');
        }
    }
}